import { createApp } from 'vue'
import './style.css'
import App from './Favoritas.vue'

createApp(App).mount('#favoritas')
